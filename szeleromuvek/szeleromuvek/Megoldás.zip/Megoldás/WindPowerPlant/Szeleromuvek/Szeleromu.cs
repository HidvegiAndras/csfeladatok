﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szeleromuvek
{
    class Szeleromu
    {
        public string TelepulesNev { get; set; }
        public string MegyeNev { get; set; }
        public string RegioNev { get; set; }
        public int TornyokSzama { get; set; }
        public int ToronyTeljesitmenyKW { get; set; }
        public int EpitesEve { get; set; }
    }
}
